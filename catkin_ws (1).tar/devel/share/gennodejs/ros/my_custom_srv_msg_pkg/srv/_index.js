
"use strict";

let MyCustomServiceMessage = require('./MyCustomServiceMessage.js')

module.exports = {
  MyCustomServiceMessage: MyCustomServiceMessage,
};
