
"use strict";

let BB8CustomServiceMessage = require('./BB8CustomServiceMessage.js')

module.exports = {
  BB8CustomServiceMessage: BB8CustomServiceMessage,
};
